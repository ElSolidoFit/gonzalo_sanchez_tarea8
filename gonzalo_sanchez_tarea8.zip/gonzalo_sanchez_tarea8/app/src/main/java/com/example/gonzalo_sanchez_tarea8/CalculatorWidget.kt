package com.example.gonzalo_sanchez_tarea8

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class CalculatorWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId, "Resultado no disponible")
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)

        if (intent.action == ACTION_UPDATE_RESULT) {
            val result = intent.getStringExtra(EXTRA_RESULT) ?: "Error"
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val appWidgetIds = appWidgetManager.getAppWidgetIds(ComponentName(context, CalculatorWidget::class.java))

            for (appWidgetId in appWidgetIds) {
                updateAppWidget(context, appWidgetManager, appWidgetId, result)
            }
        }
    }

    companion object {
        private const val ACTION_UPDATE_RESULT = "com.example.gonzalo_sanchez_tarea8.UPDATE_RESULT"
        const val EXTRA_RESULT = "com.example.gonzalo_sanchez_tarea8.RESULT"

        private fun updateAppWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, result: String) {
            val views = RemoteViews(context.packageName, R.layout.widget_layout)
            views.setTextViewText(R.id.tvWidgetResult, "Resultado: $result")

            // Configura el evento para abrir la aplicación
            val intent = Intent(context, MainActivity::class.java)
            val pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.btnOpenApp, pendingIntent)

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }

        // Función para enviar el resultado al widget
        fun sendResultToWidget(context: Context, result: String) {
            val intent = Intent(context, CalculatorWidget::class.java).apply {
                action = ACTION_UPDATE_RESULT
                putExtra(EXTRA_RESULT, result)
            }
            context.sendBroadcast(intent)
        }
    }
}
