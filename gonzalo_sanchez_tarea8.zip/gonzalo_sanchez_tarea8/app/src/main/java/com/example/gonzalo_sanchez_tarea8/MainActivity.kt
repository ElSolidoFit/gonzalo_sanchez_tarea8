package com.example.gonzalo_sanchez_tarea8

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.gonzalo_sanchez_tarea8.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupListeners()
    }

    private fun setupListeners() {
        binding.btnAdd.setOnClickListener {
            performOperation(Operation.ADD)
        }

        binding.btnSubtract.setOnClickListener {
            performOperation(Operation.SUBTRACT)
        }

        binding.btnClear.setOnClickListener {
            clearFields()
        }
    }

    private fun performOperation(operation: Operation) {
        val number1Text = binding.etNumber1.text.toString()
        val number2Text = binding.etNumber2.text.toString()

        if (number1Text.isEmpty() || number2Text.isEmpty()) {
            Toast.makeText(this, "Por favor ingresa ambos números.", Toast.LENGTH_SHORT).show()
            return
        }

        val isDecimal = binding.radioDecimal.isChecked

        try {
            val result = if (isDecimal) {
                val number1 = number1Text.toInt()
                val number2 = number2Text.toInt()
                when (operation) {
                    Operation.ADD -> number1 + number2
                    Operation.SUBTRACT -> number1 - number2
                }
            } else {
                val number1 = binaryToDecimal(number1Text)
                val number2 = binaryToDecimal(number2Text)
                when (operation) {
                    Operation.ADD -> decimalToBinary(number1 + number2)
                    Operation.SUBTRACT -> decimalToBinary(number1 - number2)
                }
            }

            binding.tvResult.text = "Resultado: $result"
            // Envía el resultado al widget
            CalculatorWidget.sendResultToWidget(this, result.toString())

        } catch (e: NumberFormatException) {
            Toast.makeText(this, "Entrada no válida. Por favor ingresa números válidos.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun decimalToBinary(decimal: Int): String {
        return Integer.toBinaryString(decimal)
    }

    private fun binaryToDecimal(binary: String): Int {
        return Integer.parseInt(binary, 2)
    }

    private fun clearFields() {
        binding.etNumber1.text.clear()
        binding.etNumber2.text.clear()
        binding.tvResult.text = "Resultado: "
        binding.radioDecimal.isChecked = true
    }

    enum class Operation {
        ADD, SUBTRACT
    }
}
